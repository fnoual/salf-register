<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AAU Inscription Webinaire</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>
<body>
    <div class="container shadow bg-white" >
        <div class="text-center py-4">
        
            <h2>
                eCongrès international de la Société <br>
                d'Andrologie de Langue Française <br> 
                21 Janvier 2020
                
            </h2>
            
            <h3 class="mt-4">
                INSCRIPTION
            </h3>

        </div>
        
        
        <?php if($errors->any()): ?>
        <div class="alert alert-danger rounded-0">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($error); ?> <br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>

        <?php if(Session::has('message')): ?>
        <div class="alert alert-success rounded-0">
             <?php echo e(Session::get('message')); ?>

        </div>
        <?php endif; ?>
        <form action="<?php echo e(url('/inscription')); ?>" method="post" class="mt-4">
        <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="nom">Nom</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> rounded-0 p-2" id="nom" name="nom" value="<?php echo e(old('nom')); ?>">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="prenom">Prénom</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['prenom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> rounded-0 p-2" id="prenom" name="prenom" value="<?php echo e(old('prenom')); ?>">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="email">Adresse e-mail</label>
                            <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> rounded-0 p-2" id="email" name="email" value="<?php echo e(old('email')); ?>">
                        </div>
                    </div>
                    
                    <div class="col-md-12">
                        <div class="form-group">
                            <button class="btn btn-outline-primary rounded-0">Inscription</button>
                        </div>
                    </div>
                </div>
            </form>

            <div class="text-center">
        <img src="<?php echo e(asset('banner.png')); ?>" alt="banner" class="w-75"></div>
    </div>
</body>
</html> <?php /**PATH /home/fnoual/Projects/lotus/inscription/resources/views/index.blade.php ENDPATH**/ ?>